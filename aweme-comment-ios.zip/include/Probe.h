#ifndef AC_PROBE_H
#define AC_PROBE_H

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/** 立即执行一次类扫描探测, 结果写入三个路径并打日志 */
void ACRunProbe(void);

/** 读取上次探测结果 (按写入优先级倒序查找), 找不到返回 nil */
NSString *ACReadProbeText(void);

/** 三指长按弹窗 (单例, 只用来当手势 target) */
/** iOS 15+ 安全的 key window（keyWindow 已废弃，多场景下返回 nil） */
UIWindow *ACKeyWindow(void);

/** 当前最适合 present 的控制器 */
UIViewController *ACTopViewController(void);

/** 统一弹窗入口 */
void ACPresentAlert(NSString *title, NSString *msg, BOOL withCopy, NSString *copyText);

@interface ACProbeShower : NSObject
+ (instancetype)sharedProxy;
- (void)handleLongPress:(UILongPressGestureRecognizer *)g;
@end

#endif
